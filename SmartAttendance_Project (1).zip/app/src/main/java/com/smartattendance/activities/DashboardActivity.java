package com.smartattendance.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.smartattendance.R;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    private static final String TAG = "DashboardActivity";
    private TextView tvTotalStudents, tvTotalPresent, tvTotalAbsent, tvDate, tvWelcome;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvTotalStudents = findViewById(R.id.tvTotalStudents);
        tvTotalPresent  = findViewById(R.id.tvTotalPresent);
        tvTotalAbsent   = findViewById(R.id.tvTotalAbsent);
        tvDate          = findViewById(R.id.tvDate);
        tvWelcome       = findViewById(R.id.tvWelcome);

        // Set defaults so screen never shows blank on error
        tvTotalStudents.setText("0");
        tvTotalPresent.setText("0");
        tvTotalAbsent.setText("0");

        String today = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(new Date());
        tvDate.setText("Date: " + today);
        tvWelcome.setText("Welcome, Admin");

        findViewById(R.id.cardStudents).setOnClickListener(v ->
            startActivity(new Intent(this, StudentListActivity.class)));
        findViewById(R.id.cardAttendance).setOnClickListener(v ->
            startActivity(new Intent(this, AttendanceActivity.class)));
        findViewById(R.id.cardHistory).setOnClickListener(v ->
            startActivity(new Intent(this, AttendanceHistoryActivity.class)));
        findViewById(R.id.cardFaceRecognition).setOnClickListener(v ->
            startActivity(new Intent(this, FaceRecognitionActivity.class)));
        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        // Init Firestore AFTER UI is ready
        try {
            db = FirebaseFirestore.getInstance();
            loadDashboardStats();
        } catch (Exception e) {
            Log.e(TAG, "Firestore init failed", e);
            // App stays open, stats just show 0
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (db != null) loadDashboardStats();
    }

    private void loadDashboardStats() {
        String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // Single query — no compound filter, no index needed
        db.collection("students").get()
            .addOnSuccessListener(snap -> {
                if (tvTotalStudents != null)
                    tvTotalStudents.setText(String.valueOf(snap.size()));
            })
            .addOnFailureListener(e -> Log.e(TAG, "students query failed", e));

        // Pull ALL today's attendance then count in Java — avoids composite index requirement
        db.collection("attendance")
            .whereEqualTo("date", todayDate)
            .get()
            .addOnSuccessListener(snap -> {
                int present = 0, absent = 0;
                for (QueryDocumentSnapshot doc : snap) {
                    String status = doc.getString("status");
                    if ("Present".equals(status)) present++;
                    else if ("Absent".equals(status)) absent++;
                }
                if (tvTotalPresent != null) tvTotalPresent.setText(String.valueOf(present));
                if (tvTotalAbsent  != null) tvTotalAbsent.setText(String.valueOf(absent));
            })
            .addOnFailureListener(e -> Log.e(TAG, "attendance query failed", e));
    }
}
