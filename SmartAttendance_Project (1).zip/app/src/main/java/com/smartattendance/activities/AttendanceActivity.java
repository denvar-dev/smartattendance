package com.smartattendance.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.smartattendance.R;
import com.smartattendance.adapters.AttendanceAdapter;
import com.smartattendance.models.Student;
import java.text.SimpleDateFormat;
import java.util.*;

public class AttendanceActivity extends AppCompatActivity implements AttendanceAdapter.OnAttendanceMarkListener {

    private RecyclerView recyclerView;
    private AttendanceAdapter adapter;
    private List<Student> studentList;
    private Map<String, String> attendanceMap; // studentId -> status
    private Button btnSubmit;
    private TextView tvDate, tvEmpty;
    private ProgressBar progressBar;
    private FirebaseFirestore db;
    private String todayDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        if (getSupportActionBar() != null) getSupportActionBar().setTitle("Mark Attendance");

        db = FirebaseFirestore.getInstance();
        studentList  = new ArrayList<>();
        attendanceMap = new HashMap<>();
        todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        recyclerView = findViewById(R.id.recyclerView);
        btnSubmit    = findViewById(R.id.btnSubmit);
        tvDate       = findViewById(R.id.tvDate);
        tvEmpty      = findViewById(R.id.tvEmpty);
        progressBar  = findViewById(R.id.progressBar);

        tvDate.setText("Date: " + new SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(new Date()));

        adapter = new AttendanceAdapter(studentList, attendanceMap, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnSubmit.setOnClickListener(v -> submitAttendance());

        loadStudents();
    }

    private void loadStudents() {
        progressBar.setVisibility(View.VISIBLE);
        db.collection("students").get().addOnSuccessListener(snap -> {
            studentList.clear();
            attendanceMap.clear();
            for (QueryDocumentSnapshot doc : snap) {
                Student s = doc.toObject(Student.class);
                s.setStudentId(doc.getId());
                studentList.add(s);
                attendanceMap.put(s.getStudentId(), "Present"); // default = present
            }
            adapter.notifyDataSetChanged();
            progressBar.setVisibility(View.GONE);
            tvEmpty.setVisibility(studentList.isEmpty() ? View.VISIBLE : View.GONE);
        });
    }

    @Override
    public void onStatusChange(String studentId, String status) {
        attendanceMap.put(studentId, status);
    }

    private void submitAttendance() {
        if (studentList.isEmpty()) {
            Toast.makeText(this, "No students to mark attendance for", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        btnSubmit.setEnabled(false);

        List<Map<String, Object>> batch = new ArrayList<>();
        for (Student s : studentList) {
            Map<String, Object> record = new HashMap<>();
            record.put("studentId", s.getStudentId());
            record.put("studentName", s.getName());
            record.put("date", todayDate);
            record.put("status", attendanceMap.getOrDefault(s.getStudentId(), "Present"));
            record.put("timestamp", Timestamp.now());
            batch.add(record);
        }

        saveBatch(batch, 0);
    }

    private void saveBatch(List<Map<String, Object>> batch, int index) {
        if (index >= batch.size()) {
            progressBar.setVisibility(View.GONE);
            btnSubmit.setEnabled(true);

            // Count absents for notification message
            long absentCount = attendanceMap.values().stream()
                .filter(s -> s.equals("Absent")).count();

            // Fire real phone notification
            NotificationHelper.sendNotification(this,
                "📋 Attendance Submitted",
                "Today's attendance saved. " + absentCount + " student(s) absent. Parents notified.");

            Toast.makeText(this, "✅ Attendance saved successfully!", Toast.LENGTH_LONG).show();
            showNotificationSimulation();
            return;
        }
        db.collection("attendance").add(batch.get(index))
            .addOnSuccessListener(ref -> saveBatch(batch, index + 1))
            .addOnFailureListener(e -> {
                progressBar.setVisibility(View.GONE);
                btnSubmit.setEnabled(true);
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            });
    }

    private void showNotificationSimulation() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("📢 Notification Sent")
            .setMessage("Simulated: Parent notifications have been sent for today's attendance.\n\n" +
                        "• SMS/Email notifications dispatched\n" +
                        "• Parents of absent students notified\n\n" +
                        "(Note: This is a prototype simulation)")
            .setPositiveButton("OK", (d, w) -> finish())
            .show();
    }
}
