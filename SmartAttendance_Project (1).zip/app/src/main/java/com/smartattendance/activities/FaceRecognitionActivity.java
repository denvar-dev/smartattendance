package com.smartattendance.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.smartattendance.R;
import com.smartattendance.models.Student;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Executor;

public class FaceRecognitionActivity extends AppCompatActivity {

    private ImageView ivCaptured;
    private Button btnCapture, btnBiometric, btnMarkAttendance;
    private TextView tvStatus;
    private Spinner spinnerStudents;
    private ProgressBar progressBar;
    private FirebaseFirestore db;

    private List<Student> studentList = new ArrayList<>();
    private ArrayAdapter<String> spinnerAdapter;
    private List<String> studentNames = new ArrayList<>();
    private boolean verified = false;
    private Uri photoUri;

    // Modern camera launcher — fixes Android 11+ crash
    private final ActivityResultLauncher<Uri> cameraLauncher =
        registerForActivityResult(new ActivityResultContracts.TakePicture(), success -> {
            if (success) {
                ivCaptured.setImageURI(photoUri);
                simulateRecognition();
            } else {
                Toast.makeText(this, "Camera cancelled", Toast.LENGTH_SHORT).show();
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_face_recognition);

        if (getSupportActionBar() != null) getSupportActionBar().setTitle("Smart Attendance");

        ivCaptured        = findViewById(R.id.ivCaptured);
        btnCapture        = findViewById(R.id.btnCapture);
        btnMarkAttendance = findViewById(R.id.btnMarkAttendance);
        btnBiometric      = findViewById(R.id.btnBiometric);
        tvStatus          = findViewById(R.id.tvStatus);
        spinnerStudents   = findViewById(R.id.spinnerStudents);
        progressBar       = findViewById(R.id.progressBar);

        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, studentNames);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStudents.setAdapter(spinnerAdapter);

        btnCapture.setOnClickListener(v -> openCamera());
        btnBiometric.setOnClickListener(v -> startBiometric());
        btnMarkAttendance.setOnClickListener(v -> markAttendance());

        try {
            db = FirebaseFirestore.getInstance();
            loadStudents();
        } catch (Exception e) {
            tvStatus.setText("Error connecting. Check internet.");
        }
    }

    private void loadStudents() {
        db.collection("students").get().addOnSuccessListener(snap -> {
            studentList.clear();
            studentNames.clear();
            for (QueryDocumentSnapshot doc : snap) {
                Student s = doc.toObject(Student.class);
                s.setStudentId(doc.getId());
                studentList.add(s);
                studentNames.add(s.getName() + " (" + s.getRollNumber() + ")");
            }
            spinnerAdapter.notifyDataSetChanged();
            if (studentList.isEmpty()) tvStatus.setText("No students found. Add students first.");
        }).addOnFailureListener(e -> tvStatus.setText("Could not load students."));
    }

    // ── CAMERA (fixed for Android 11+) ──────────────────────────────────────
    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA}, 100);
            return;
        }
        try {
            File photoFile = createImageFile();
            photoUri = FileProvider.getUriForFile(this,
                "com.smartattendance.fileprovider", photoFile);
            cameraLauncher.launch(photoUri);
        } catch (IOException e) {
            Toast.makeText(this, "Cannot open camera: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (storageDir != null && !storageDir.exists()) storageDir.mkdirs();
        return File.createTempFile("FACE_" + timeStamp, ".jpg", storageDir);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 100 && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else {
            Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    private void simulateRecognition() {
        verified = false;
        btnMarkAttendance.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        tvStatus.setText("🔍 Analyzing face...");
        tvStatus.setTextColor(getResources().getColor(android.R.color.holo_orange_dark));

        new Handler().postDelayed(() -> {
            progressBar.setVisibility(View.GONE);
            verified = true;
            tvStatus.setText("✅ Face Recognized Successfully!");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            btnMarkAttendance.setEnabled(true);
        }, 2000);
    }

    // ── BIOMETRIC ────────────────────────────────────────────────────────────
    private void startBiometric() {
        BiometricManager biometricManager = BiometricManager.from(this);
        int canAuth = biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK |
            BiometricManager.Authenticators.DEVICE_CREDENTIAL);

        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Biometric not available on this device", Toast.LENGTH_SHORT).show();
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    verified = true;
                    tvStatus.setText("✅ Biometric Verified!");
                    tvStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                    btnMarkAttendance.setEnabled(true);
                    Toast.makeText(FaceRecognitionActivity.this,
                        "Identity verified!", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAuthenticationFailed() {
                    super.onAuthenticationFailed();
                    Toast.makeText(FaceRecognitionActivity.this,
                        "Authentication failed. Try again.", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAuthenticationError(int errorCode, CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    Toast.makeText(FaceRecognitionActivity.this,
                        "Error: " + errString, Toast.LENGTH_SHORT).show();
                }
            });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
            .setTitle("Smart Attendance")
            .setSubtitle("Verify identity to mark attendance")
            .setDescription("Use fingerprint or face unlock")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK |
                BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build();

        biometricPrompt.authenticate(promptInfo);
    }

    // ── MARK ATTENDANCE ──────────────────────────────────────────────────────
    private void markAttendance() {
        if (!verified) {
            Toast.makeText(this, "Please verify identity first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (studentList.isEmpty()) {
            Toast.makeText(this, "No student selected", Toast.LENGTH_SHORT).show();
            return;
        }

        int pos = spinnerStudents.getSelectedItemPosition();
        if (pos < 0 || pos >= studentList.size()) return;
        Student selected = studentList.get(pos);
        String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        progressBar.setVisibility(View.VISIBLE);
        btnMarkAttendance.setEnabled(false);

        Map<String, Object> record = new HashMap<>();
        record.put("studentId", selected.getStudentId());
        record.put("studentName", selected.getName());
        record.put("date", todayDate);
        record.put("status", "Present");
        record.put("timestamp", Timestamp.now());
        record.put("markedBy", "Biometric/FaceRecognition");

        db.collection("attendance").add(record)
            .addOnSuccessListener(ref -> {
                progressBar.setVisibility(View.GONE);
                // Fire real phone notification
                NotificationHelper.sendNotification(this,
                    "✅ Attendance Marked",
                    selected.getName() + " marked Present via Smart Recognition");

                new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("✅ Attendance Marked")
                    .setMessage("Student: " + selected.getName()
                        + "\nRoll No: " + selected.getRollNumber()
                        + "\nStatus: Present"
                        + "\nDate: " + todayDate
                        + "\nMethod: Smart Recognition")
                    .setPositiveButton("OK", (d, w) -> {
                        verified = false;
                        btnMarkAttendance.setEnabled(false);
                        tvStatus.setText("Ready to scan");
                        tvStatus.setTextColor(getResources().getColor(android.R.color.darker_gray));
                        ivCaptured.setImageResource(R.drawable.ic_face_placeholder);
                    })
                    .show();
            })
            .addOnFailureListener(e -> {
                progressBar.setVisibility(View.GONE);
                btnMarkAttendance.setEnabled(true);
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            });
    }
}

