package com.smartattendance.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.smartattendance.R;
import com.smartattendance.adapters.StudentAdapter;
import com.smartattendance.models.Student;
import java.util.ArrayList;
import java.util.List;

public class StudentListActivity extends AppCompatActivity implements StudentAdapter.OnStudentClickListener {

    private RecyclerView recyclerView;
    private StudentAdapter adapter;
    private List<Student> studentList;
    private FloatingActionButton fabAdd;
    private TextView tvEmpty;
    private ProgressBar progressBar;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);

        if (getSupportActionBar() != null) getSupportActionBar().setTitle("Students");

        db = FirebaseFirestore.getInstance();
        studentList = new ArrayList<>();

        recyclerView = findViewById(R.id.recyclerView);
        fabAdd       = findViewById(R.id.fabAdd);
        tvEmpty      = findViewById(R.id.tvEmpty);
        progressBar  = findViewById(R.id.progressBar);

        adapter = new StudentAdapter(studentList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        fabAdd.setOnClickListener(v ->
            startActivity(new Intent(this, AddStudentActivity.class)));

        loadStudents();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadStudents();
    }

    private void loadStudents() {
        progressBar.setVisibility(View.VISIBLE);
        db.collection("students").get().addOnSuccessListener(snap -> {
            studentList.clear();
            for (QueryDocumentSnapshot doc : snap) {
                Student s = doc.toObject(Student.class);
                s.setStudentId(doc.getId());
                studentList.add(s);
            }
            adapter.notifyDataSetChanged();
            progressBar.setVisibility(View.GONE);
            tvEmpty.setVisibility(studentList.isEmpty() ? View.VISIBLE : View.GONE);
        }).addOnFailureListener(e -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Error loading students", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onEditClick(Student student) {
        Intent intent = new Intent(this, AddStudentActivity.class);
        intent.putExtra("studentId", student.getStudentId());
        intent.putExtra("name", student.getName());
        intent.putExtra("rollNumber", student.getRollNumber());
        intent.putExtra("className", student.getClassName());
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(Student student) {
        new AlertDialog.Builder(this)
            .setTitle("Delete Student")
            .setMessage("Are you sure you want to delete " + student.getName() + "?")
            .setPositiveButton("Delete", (dialog, which) -> {
                db.collection("students").document(student.getStudentId()).delete()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Student deleted", Toast.LENGTH_SHORT).show();
                        loadStudents();
                    });
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
