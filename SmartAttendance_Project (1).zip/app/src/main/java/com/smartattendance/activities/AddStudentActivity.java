package com.smartattendance.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import com.smartattendance.R;
import java.util.HashMap;
import java.util.Map;

public class AddStudentActivity extends AppCompatActivity {

    private EditText etName, etRollNumber, etClass;
    private Button btnSave;
    private ProgressBar progressBar;
    private FirebaseFirestore db;
    private String editStudentId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        db = FirebaseFirestore.getInstance();

        etName       = findViewById(R.id.etName);
        etRollNumber = findViewById(R.id.etRollNumber);
        etClass      = findViewById(R.id.etClass);
        btnSave      = findViewById(R.id.btnSave);
        progressBar  = findViewById(R.id.progressBar);

        // Check if editing existing student
        if (getIntent().hasExtra("studentId")) {
            editStudentId = getIntent().getStringExtra("studentId");
            etName.setText(getIntent().getStringExtra("name"));
            etRollNumber.setText(getIntent().getStringExtra("rollNumber"));
            etClass.setText(getIntent().getStringExtra("className"));
            btnSave.setText("Update Student");
            if (getSupportActionBar() != null) getSupportActionBar().setTitle("Edit Student");
        } else {
            if (getSupportActionBar() != null) getSupportActionBar().setTitle("Add Student");
        }

        btnSave.setOnClickListener(v -> saveStudent());
    }

    private void saveStudent() {
        String name   = etName.getText().toString().trim();
        String roll   = etRollNumber.getText().toString().trim();
        String cls    = etClass.getText().toString().trim();

        if (TextUtils.isEmpty(name)) { etName.setError("Name required"); return; }
        if (TextUtils.isEmpty(roll)) { etRollNumber.setError("Roll number required"); return; }
        if (TextUtils.isEmpty(cls))  { etClass.setError("Class required"); return; }

        progressBar.setVisibility(View.VISIBLE);
        btnSave.setEnabled(false);

        Map<String, Object> student = new HashMap<>();
        student.put("name", name);
        student.put("rollNumber", roll);
        student.put("className", cls);

        if (editStudentId != null) {
            db.collection("students").document(editStudentId).update(student)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Student updated!", Toast.LENGTH_SHORT).show();
                    finish();
                }).addOnFailureListener(e -> showError(e.getMessage()));
        } else {
            db.collection("students").add(student)
                .addOnSuccessListener(docRef -> {
                    Toast.makeText(this, "Student added!", Toast.LENGTH_SHORT).show();
                    finish();
                }).addOnFailureListener(e -> showError(e.getMessage()));
        }
    }

    private void showError(String msg) {
        progressBar.setVisibility(View.GONE);
        btnSave.setEnabled(true);
        Toast.makeText(this, "Error: " + msg, Toast.LENGTH_LONG).show();
    }
}
