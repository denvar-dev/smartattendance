package com.smartattendance.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.smartattendance.R;
import com.smartattendance.adapters.HistoryAdapter;
import com.smartattendance.models.Attendance;
import java.util.ArrayList;
import java.util.List;

public class AttendanceHistoryActivity extends AppCompatActivity {

    private static final String TAG = "HistoryActivity";
    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    private List<Attendance> attendanceList;
    private TextView tvEmpty;
    private ProgressBar progressBar;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_history);

        if (getSupportActionBar() != null) getSupportActionBar().setTitle("Attendance History");

        attendanceList = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty      = findViewById(R.id.tvEmpty);
        progressBar  = findViewById(R.id.progressBar);

        adapter = new HistoryAdapter(attendanceList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        try {
            db = FirebaseFirestore.getInstance();
            loadHistory();
        } catch (Exception e) {
            Log.e(TAG, "Firestore init failed", e);
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Could not load history.");
        }
    }

    private void loadHistory() {
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
        db.collection("attendance")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(100)
            .get()
            .addOnSuccessListener(snap -> {
                attendanceList.clear();
                for (QueryDocumentSnapshot doc : snap) {
                    Attendance a = doc.toObject(Attendance.class);
                    a.setAttendanceId(doc.getId());
                    attendanceList.add(a);
                }
                adapter.notifyDataSetChanged();
                if (progressBar != null) progressBar.setVisibility(View.GONE);
                if (tvEmpty != null)
                    tvEmpty.setVisibility(attendanceList.isEmpty() ? View.VISIBLE : View.GONE);
            })
            .addOnFailureListener(e -> {
                Log.e(TAG, "load failed", e);
                if (progressBar != null) progressBar.setVisibility(View.GONE);
                if (tvEmpty != null) {
                    tvEmpty.setVisibility(View.VISIBLE);
                    tvEmpty.setText("No records found.");
                }
            });
    }
}
