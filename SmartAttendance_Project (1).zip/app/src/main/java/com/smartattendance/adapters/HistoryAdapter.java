package com.smartattendance.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.smartattendance.R;
import com.smartattendance.models.Attendance;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<Attendance> list;

    public HistoryAdapter(List<Attendance> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_history, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Attendance a = list.get(position);
        holder.tvName.setText(a.getStudentName());
        holder.tvDate.setText("Date: " + a.getDate());
        holder.tvStatus.setText(a.getStatus());

        if ("Present".equals(a.getStatus())) {
            holder.tvStatus.setTextColor(Color.parseColor("#2E7D32"));
            holder.tvStatus.setBackgroundResource(R.drawable.bg_present);
        } else {
            holder.tvStatus.setTextColor(Color.parseColor("#C62828"));
            holder.tvStatus.setBackgroundResource(R.drawable.bg_absent);
        }
    }

    @Override
    public int getItemCount() { return list.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDate, tvStatus;

        ViewHolder(View v) {
            super(v);
            tvName   = v.findViewById(R.id.tvName);
            tvDate   = v.findViewById(R.id.tvDate);
            tvStatus = v.findViewById(R.id.tvStatus);
        }
    }
}
