package com.smartattendance.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.smartattendance.R;
import com.smartattendance.models.Student;
import java.util.List;
import java.util.Map;

public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.ViewHolder> {

    public interface OnAttendanceMarkListener {
        void onStatusChange(String studentId, String status);
    }

    private List<Student> students;
    private Map<String, String> attendanceMap;
    private OnAttendanceMarkListener listener;

    public AttendanceAdapter(List<Student> students, Map<String, String> attendanceMap,
                             OnAttendanceMarkListener listener) {
        this.students = students;
        this.attendanceMap = attendanceMap;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_attendance, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Student s = students.get(position);
        holder.tvName.setText(s.getName());
        holder.tvRoll.setText("Roll: " + s.getRollNumber());

        String status = attendanceMap.getOrDefault(s.getStudentId(), "Present");
        holder.rbPresent.setChecked(status.equals("Present"));
        holder.rbAbsent.setChecked(status.equals("Absent"));

        holder.rgStatus.setOnCheckedChangeListener((group, checkedId) -> {
            String newStatus = (checkedId == R.id.rbPresent) ? "Present" : "Absent";
            attendanceMap.put(s.getStudentId(), newStatus);
            listener.onStatusChange(s.getStudentId(), newStatus);
        });
    }

    @Override
    public int getItemCount() { return students.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvRoll;
        RadioGroup rgStatus;
        RadioButton rbPresent, rbAbsent;

        ViewHolder(View v) {
            super(v);
            tvName    = v.findViewById(R.id.tvName);
            tvRoll    = v.findViewById(R.id.tvRoll);
            rgStatus  = v.findViewById(R.id.rgStatus);
            rbPresent = v.findViewById(R.id.rbPresent);
            rbAbsent  = v.findViewById(R.id.rbAbsent);
        }
    }
}
