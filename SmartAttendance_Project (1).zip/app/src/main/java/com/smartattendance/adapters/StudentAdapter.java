package com.smartattendance.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.smartattendance.R;
import com.smartattendance.models.Student;
import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {

    public interface OnStudentClickListener {
        void onEditClick(Student student);
        void onDeleteClick(Student student);
    }

    private List<Student> students;
    private OnStudentClickListener listener;

    public StudentAdapter(List<Student> students, OnStudentClickListener listener) {
        this.students = students;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_student, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Student s = students.get(position);
        holder.tvName.setText(s.getName());
        holder.tvRoll.setText("Roll: " + s.getRollNumber());
        holder.tvClass.setText("Class: " + s.getClassName());

        holder.btnEdit.setOnClickListener(v -> listener.onEditClick(s));
        holder.btnDelete.setOnClickListener(v -> listener.onDeleteClick(s));
    }

    @Override
    public int getItemCount() { return students.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvRoll, tvClass;
        ImageButton btnEdit, btnDelete;

        ViewHolder(View v) {
            super(v);
            tvName    = v.findViewById(R.id.tvName);
            tvRoll    = v.findViewById(R.id.tvRoll);
            tvClass   = v.findViewById(R.id.tvClass);
            btnEdit   = v.findViewById(R.id.btnEdit);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}
