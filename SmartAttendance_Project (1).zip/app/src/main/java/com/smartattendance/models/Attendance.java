package com.smartattendance.models;

import com.google.firebase.Timestamp;

public class Attendance {
    private String attendanceId;
    private String studentId;
    private String studentName;
    private String date;
    private String status; // "Present" or "Absent"
    private Timestamp timestamp;

    public Attendance() {}

    public Attendance(String attendanceId, String studentId, String studentName,
                      String date, String status, Timestamp timestamp) {
        this.attendanceId = attendanceId;
        this.studentId = studentId;
        this.studentName = studentName;
        this.date = date;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getAttendanceId() { return attendanceId; }
    public void setAttendanceId(String attendanceId) { this.attendanceId = attendanceId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Timestamp getTimestamp() { return timestamp; }
    public void setTimestamp(Timestamp timestamp) { this.timestamp = timestamp; }
}
